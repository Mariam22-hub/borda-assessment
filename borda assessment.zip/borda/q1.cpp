#include <bits/stdc++.h>
#include <cmath>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>

#define pq priority_queue;
#define endl '\n';
#define ff first;
#define ss second;
#define pb push_back;
#define FIO()                         \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);                    \
    cout.tie(NULL);

using namespace std;
using ld = long double;

typedef long long ll;
typedef vector<pair<int, bool>> vpair;
typedef vector<int> vec;
string line;

using namespace std;

//  a structure for storing the coordinates of a point
struct Point {
    double x, y;

    Point(double x = 0, double y = 0) : x(x), y(y) {}
};

struct Segment {
    Point p1, p2;

    Segment(Point p1 = Point(), Point p2 = Point()) : p1(p1), p2(p2) {}
};

// a function to compute the distance between two points
double distance(Point p1, Point p2) {
    double dx = p1.x - p2.x;
    double dy = p1.y - p2.y;
    return sqrt((dx * dx) + (dy * dy));
}

// a function to check if a point is inside a polygon
bool pointInPolygon(const Point &p, const vector<Point> &polygon) {  //--
    int n = polygon.size();
    bool inside = false;

    for (int i = 0, j = n - 1; i < n; j = i++) {
        if (((polygon[i].y <= p.y && p.y < polygon[j].y) || (polygon[j].y <= p.y && p.y < polygon[i].y)) &&
            (p.x < (polygon[j].x - polygon[i].x) * (p.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x)) {
            inside = !inside;
        }
    }
    return inside;
}

// line intersection equation (computational geometry)
bool segmentIntersectsSegment(const Segment &s1, const Segment &s2) {  //--
    double x1 = s1.p1.x,
    y1 = s1.p1.y,
    x2 = s1.p2.x,
    y2 = s1.p2.y;

    double x3 = s2.p1.x,
    y3 = s2.p1.y,
    x4 = s2.p2.x,
    y4 = s2.p2.y;


//    By dividing the numerator by the cross product, the formulas give you the relative positions of the intersection point along the two line segments.
    double ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));
    double ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));

    return (0 <= ua && ua <= 1 && 0 <= ub && ub <= 1);
}


bool arePointsPassable(const Point &p1, const Point &p2, const vector<vector<Point>> &polygons,
                       const vector<Segment> &passages) {

    double dist = distance(p1, p2);

    if (dist <= 1) {
        for (const vector<Point> &polygon: polygons) {

            if (pointInPolygon(p1, polygon) && pointInPolygon(p2, polygon)) {
                return true;
            }
        }
        // check if points are in different polygons with a passage in between
        for (Segment seg: passages) {
            if (segmentIntersectsSegment(seg, Segment(p1, p2))) {
                return true; // passable
            }
        }
        // no passage between the points
        return false; // not passable
    } else {
        return false;
    }

}

int checkFile(std::ifstream &inputFile) {
    if (inputFile.peek() == std::ifstream::traits_type::eof()) {
        std::cout << "Input file is empty\n";
        return 0;
    }

    return 1;
}

vector<vector<Point>> readPolygons(std::ifstream &inputFile) {
    // Check if the input file is empty
    vector<vector<Point>> polygons;

    if (!checkFile(inputFile)) exit(0);

    while (std::getline(inputFile, line) && !line.empty()) {
        std::vector<Point> poly;
        size_t pos = 0;

        while (pos < line.size()) {

            size_t endPos = line.find(';', pos);

            if (endPos == std::string::npos) {
                endPos = line.size();
            }

            size_t commaPos = line.find(',', pos);

            if (commaPos == std::string::npos || commaPos > endPos) {
                break;
            }

            double x = std::stod(line.substr(pos, commaPos - pos));
            double y = std::stod(line.substr(commaPos + 1, endPos - commaPos - 1));
            poly.push_back(Point(x, y));
            pos = endPos + 1;
        }
        polygons.push_back(poly);
    }

    return polygons;

}

vector<Segment> readSegments(std::ifstream &inputFile) {
    std::vector<Segment> segments;

    if (!checkFile(inputFile)) exit(0);

    while (std::getline(inputFile, line) && !line.empty()) {
        size_t pos = 0;
        size_t commaPos = line.find(',', pos);
        size_t endPos = line.find(';', pos);

        if (endPos == std::string::npos) {
            endPos = line.size();
        }

        double x1 = std::stod(line.substr(pos, commaPos - pos));
        pos = commaPos + 1;

        double y1 = std::stod(line.substr(pos, commaPos - pos));
        pos = endPos + 1;

        commaPos = line.find(',', pos);

        double x2 = std::stod(line.substr(pos, commaPos - pos));
        pos = commaPos + 1;
        double y2 = std::stod(line.substr(pos));


        segments.push_back(Segment(Point(x1, y1), Point(x2, y2)));

    }
    return segments;
}


// BEFORE RUNNING, MAKE SURE TO CHANGE THE RUN CONFIGURATION TO EXECUTE THE RIGHT PROBLEM -> (problem 1)
int main() {

    cout << "In problem 1" << endl;
    FIO();

    std::ifstream inputFile("input_q1.txt");

    // Read the polygons from the input file
    vector<vector<Point>> polygons = readPolygons(inputFile);

// Read the passages from the input file
    std::vector<Segment> passages = readSegments(inputFile);


// Read the test points from the input file
    std::vector<Segment> testPoints = readSegments(inputFile);;

    inputFile.close();

    std::ofstream outputFile("q1_output.txt");

    // Check if each pair of test points is passable and write the result to the output file
    for (int i = 0; i < testPoints.size(); i += 1) {

        Point p1 = testPoints[i].p1;
        Point p2 = testPoints[i].p2;

        bool passable = arePointsPassable(p1, p2, polygons, passages);

//        cout << passable << endl;
        outputFile << (passable ? 1 : 0) << endl;
    }

    outputFile.close();
    cout << "Done" << endl;

    return 0;

}


